clc;
clear all;

n = 85;
A = condmat(n,1e7);
x = randn(n,1);
b = A*x;
% CHOLESKY DECOMPOSTION
% xhat is the solution obtained using cholesky decomp
tic;
chol_xhat = A\b;
chol_time_taken = toc

% chol_r is the residual
chol_r = A*chol_xhat;

% Calculating inf norm of the errors
chol_forward_error = norm(x - chol_xhat,inf)/norm(x,inf)
chol_residual_error = norm(chol_r - b,inf)/norm(b,inf)


% CRAMER'S DECOMPOSITION
tic;
cramer_xhat = cramer(A,b);
cramer_time_taken = toc

% residual cramer_r
cramer_r = A*cramer_xhat;

% Calculating inf norm of the errors
cramer_forward_error = norm(x - cramer_xhat,inf)/norm(x,inf)
cramer_residual_error = norm(cramer_r - b,inf)/norm(b,inf)