clc;
format long e

x = 1;
k = 0;

while 1 + x > 1
    x = x / 2;
    k = k + 1;
end
fprintf('first program values\n');
x
k

x = 1;
k = 0;
while x + x > x
    x = x / 2;
    k = k + 1;
end
fprintf('Second program values\n');
x
k

fprintf("Let the floating point system in use be (b,p,E_min,E_max)\n" + ...
    "In the 1st situation, since we are adding x to 1, any value of x less than the order of 1e-p will be rounded down to 0.\n" + ...
    "This is a result of the large difference in the orders of the operands.\n\n" + ...
    "In the second situation, since we are adding x to x itself, the order of both operands is the same.\n" + ...
    "This allows the value of x to go down to the order of 1eE_min without being rounded down to 0. \n\n");
fprintf("Both algorithms end when the value of x = 0 in the floating point representation.\n")
fprintf("Therefore the 2nd algorithm loops more than the 1st \n");