function y = cramer(A,b)
   n = length(A(1,:));
   x = zeros(n,1);
   det_A = det(A);
   
   for i = 1:n
       A_i = A;
       A_i(:,i) = b;
       x(i) = det(A_i) / det_A;
   end
   
   y = x;
end